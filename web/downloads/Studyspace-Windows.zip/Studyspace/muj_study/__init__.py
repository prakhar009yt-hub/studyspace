"""Personal, local study assistant."""
